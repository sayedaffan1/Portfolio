import "./App.css";
import Background3D from "./components/Background3D";
import Navbar from "./components/Navbar";
import { FaGithub, FaLinkedin, FaEnvelope, FaArrowUpRightFromSquare } from "react-icons/fa6";

const skills = [
  "Python","HTML","CSS","JavaScript","MySQL","SQL","Kali Linux","Nmap",
  "Wireshark","Burp Suite","Tenable Nessus","Bash","VMware","Packet Tracer"
];

const projects = [
  ["01","Secure Remote Access Solution","Developed a secure remote access solution focused on confidentiality, integrity, authentication, and protecting corporate resources for remote employees."],
  ["02","Secure Password Manager","Developed a secure password management system with strong encryption, MFA, RBAC, encrypted backups, usability features, and compliance monitoring."],
  ["03","Secure Email Communication","Implemented a secure email system focused on confidentiality, integrity, and authentication of sensitive organizational data."],
  ["04","Host Header Injection Testing","Used Burp Suite to intercept requests and manipulate Host headers to identify and validate server-side vulnerabilities."],
  ["05","Open Redirection Testing","Identified an open redirection vulnerability using security headers and validated the risk using Burp Suite."],
  ["06","IoT Smart Home Security","Developed a comprehensive IoT security framework to protect smart home devices from cyber-attacks, supporting safety, privacy, and reliability."]
];

function App() {
  return (
    <>
      <Background3D />
      <Navbar />
      <main>
        <section className="hero" id="home">
          <div className="eyebrow">● AVAILABLE FOR OPPORTUNITIES</div>
          <p className="hello">HELLO, I'M</p>
          <h1>AFFAN <span>SAYED.</span></h1>
          <div className="hero-bottom">
            <p>Cybersecurity enthusiast with a foundation in ethical hacking, network security, vulnerability assessment, and penetration testing.</p>
            <div className="hero-actions">
              <a href="#projects" className="btn primary">Explore Projects <FaArrowUpRightFromSquare /></a>
              <a href="#contact" className="btn ghost">Let's Connect</a>
            </div>
          </div>
          <div className="scroll-hint">SCROLL TO EXPLORE ↓</div>
        </section>

        <section className="section about" id="about">
          <div className="section-label">01 / ABOUT</div>
          <div className="section-grid">
            <h2>Building a safer<br/><span>digital world.</span></h2>
            <div className="about-copy">
              <p>I'm a motivated and detail-oriented cybersecurity enthusiast with a strong foundation in ethical hacking, network security, and penetration testing.</p>
              <p>I enjoy identifying vulnerabilities, assessing security risks, and continuously learning new technologies to strengthen cybersecurity defenses.</p>
              <div className="stats">
                <div><strong>01+</strong><span>Year Internship Experience</span></div>
                <div><strong>06</strong><span>Security Projects</span></div>
                <div><strong>14+</strong><span>Technical Skills</span></div>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="skills">
          <div className="section-label">02 / TECHNICAL SKILLS</div>
          <h2 className="section-title">Tools I use to <span>secure.</span></h2>
          <div className="skills-cloud">
            {skills.map((skill, i) => <div className="skill" key={skill}><span>{String(i+1).padStart(2,"0")}</span>{skill}</div>)}
          </div>
        </section>

        <section className="section experience" id="experience">
          <div className="section-label">03 / EXPERIENCE</div>
          <div className="experience-card">
            <div className="experience-top">
              <span>JUN 2025 — JAN 2026</span>
              <span>MUMBAI, INDIA</span>
            </div>
            <h2>Cybersecurity Specialist <span>Intern</span></h2>
            <h3>First Quadrant Labs</h3>
            <p>Contributed to multiple cybersecurity projects involving secure remote access, password security, secure communication, web vulnerability testing, and IoT security.</p>
          </div>
        </section>

        <section className="section" id="projects">
          <div className="section-label">04 / FEATURED WORK</div>
          <h2 className="section-title">Security projects.<br/><span>Real-world thinking.</span></h2>
          <div className="projects-grid">
            {projects.map(([num,title,text]) => (
              <article className="project-card" key={num}>
                <div className="project-num">{num}</div>
                <h3>{title}</h3>
                <p>{text}</p>
                <div className="project-line"></div>
                <span className="project-arrow">↗</span>
              </article>
            ))}
          </div>
        </section>

        <section className="section education" id="education">
          <div className="section-label">05 / EDUCATION & COURSES</div>
          <div className="timeline">
            <div><span>2025 — 2026</span><h3>Bachelor of Commerce (BCom)</h3><p>Shree Ram College · Mumbai, India</p></div>
            <div><span>2024 — 2025</span><h3>Cyber Security & Ethical Hacking</h3><p>Boston Institute of Analytics · Mumbai, India</p></div>
            <div><span>2023 — 2024</span><h3>Master in Data Software Engineering</h3><p>ITVedant · Mumbai, Maharashtra</p></div>
          </div>
        </section>

        <section className="contact-section" id="contact">
          <div className="section-label">06 / CONTACT</div>
          <p className="contact-small">HAVE AN OPPORTUNITY OR WANT TO CONNECT?</p>
          <h2>Let's make something<br/><span>secure together.</span></h2>
          <a className="email-link" href="mailto:aaaffansayed@gmail.com">aaaffansayed@gmail.com ↗</a>
          <div className="contact-links">
            <a href="https://github.com/sayedaffan1" target="_blank" rel="noreferrer"><FaGithub /> GitHub</a>
            <a href="https://linkedin.com/in/affan-sayed-21b968256/" target="_blank" rel="noreferrer"><FaLinkedin /> LinkedIn</a>
            <a href="mailto:aaaffansayed@gmail.com"><FaEnvelope /> Email</a>
          </div>
        </section>
      </main>
      <footer>© 2026 AFFAN SAYED · CYBERSECURITY PORTFOLIO</footer>
    </>
  );
}

export default App;