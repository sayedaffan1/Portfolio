import { useState } from "react";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const links = [["Home","home"],["About","about"],["Skills","skills"],["Experience","experience"],["Projects","projects"],["Contact","contact"]];
  return (
    <nav className="navbar">
      <a className="brand" href="#home">AF<span>_</span></a>
      <button className="mobile-toggle" onClick={() => setOpen(!open)}>{open ? "×" : "☰"}</button>
      <div className={`navlinks ${open ? "open" : ""}`}>
        {links.map(([name,id]) => <a key={id} href={`#${id}`} onClick={() => setOpen(false)}>{name}</a>)}
      </div>
      <a href="#contact" className="nav-cta">CONTACT ↗</a>
    </nav>
  );
}