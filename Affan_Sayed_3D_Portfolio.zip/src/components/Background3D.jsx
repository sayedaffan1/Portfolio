import { Canvas, useFrame } from "@react-three/fiber";
import { Points, PointMaterial } from "@react-three/drei";
import { useMemo, useRef } from "react";

function Particles() {
  const ref = useRef();
  const positions = useMemo(() => {
    const a = new Float32Array(2400 * 3);
    for (let i = 0; i < a.length; i++) a[i] = (Math.random() - .5) * 24;
    return a;
  }, []);
  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * .018;
      ref.current.rotation.x = Math.sin(state.clock.elapsedTime * .08) * .08;
    }
  });
  return <points ref={ref}><bufferGeometry><bufferAttribute attach="attributes-position" array={positions} count={positions.length/3} itemSize={3}/></bufferGeometry><PointMaterial transparent color="#64f5d4" size={0.018} sizeAttenuation depthWrite={false}/></points>;
}
function Orb() {
  const ref = useRef();
  useFrame((state) => {
    if (!ref.current) return;
    ref.current.rotation.x = state.clock.elapsedTime * .12;
    ref.current.rotation.y = state.clock.elapsedTime * .18;
    ref.current.position.y = Math.sin(state.clock.elapsedTime * .7) * .45;
  });
  return <mesh ref={ref} position={[5, .5, -4]}><icosahedronGeometry args={[1.7,2]}/><meshBasicMaterial color="#20d9c2" wireframe transparent opacity={.28}/></mesh>;
}
export default function Background3D() {
  return <div className="three-bg"><Canvas camera={{position:[0,0,7],fov:60}}><Particles/><Orb/></Canvas></div>;
}